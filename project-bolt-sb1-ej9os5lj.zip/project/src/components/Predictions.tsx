import React from 'react';
import { TrendingUp, Brain, Calendar, CloudRain, Users } from 'lucide-react';

const Predictions: React.FC = () => {
  const predictions = [
    { time: '8:00 AM', volume: 12500, confidence: 94, weather: 'Clear', events: 0 },
    { time: '9:00 AM', volume: 14200, confidence: 91, weather: 'Clear', events: 1 },
    { time: '10:00 AM', volume: 9800, confidence: 87, weather: 'Partly Cloudy', events: 0 },
    { time: '11:00 AM', volume: 8200, confidence: 89, weather: 'Partly Cloudy', events: 0 },
    { time: '12:00 PM', volume: 11600, confidence: 92, weather: 'Clear', events: 2 },
    { time: '1:00 PM', volume: 10400, confidence: 88, weather: 'Clear', events: 1 },
    { time: '2:00 PM', volume: 9200, confidence: 85, weather: 'Rain', events: 0 },
  ];

  const factors = [
    { name: 'Weather Conditions', impact: 23, trend: 'increasing' },
    { name: 'Special Events', impact: 18, trend: 'stable' },
    { name: 'Historical Patterns', impact: 45, trend: 'stable' },
    { name: 'Day of Week', impact: 14, trend: 'decreasing' },
  ];

  const alerts = [
    { type: 'warning', message: 'Heavy rain expected at 2:00 PM - 25% traffic increase predicted', time: '2 hours' },
    { type: 'info', message: 'Concert at stadium - traffic surge expected around 7:00 PM', time: '5 hours' },
    { type: 'success', message: 'Optimal travel window: 10:30 AM - 11:30 AM', time: 'Now' },
  ];

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 90) return 'text-green-400';
    if (confidence >= 80) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getAlertColor = (type: string) => {
    switch (type) {
      case 'warning':
        return 'bg-yellow-900 border-yellow-600 text-yellow-200';
      case 'info':
        return 'bg-blue-900 border-blue-600 text-blue-200';
      case 'success':
        return 'bg-green-900 border-green-600 text-green-200';
      default:
        return 'bg-gray-900 border-gray-600 text-gray-200';
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Traffic Predictions</h2>
        <div className="flex items-center space-x-2 text-sm text-gray-400">
          <Brain className="w-4 h-4" />
          <span>AI-Powered Forecasting</span>
        </div>
      </div>

      {/* Prediction Alerts */}
      <div className="space-y-3">
        {alerts.map((alert, index) => (
          <div key={index} className={`border rounded-lg p-4 ${getAlertColor(alert.type)}`}>
            <div className="flex items-center justify-between">
              <p className="font-medium">{alert.message}</p>
              <span className="text-xs opacity-75">in {alert.time}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Hourly Predictions */}
      <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Hourly Volume Predictions</h3>
        <div className="space-y-4">
          {predictions.map((prediction, index) => (
            <div key={index} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="text-center">
                  <p className="text-white font-medium">{prediction.time}</p>
                  <p className="text-gray-400 text-sm">Time</p>
                </div>
                <div className="text-center">
                  <p className="text-white font-bold text-lg">{prediction.volume.toLocaleString()}</p>
                  <p className="text-gray-400 text-sm">Vehicles</p>
                </div>
                <div className="text-center">
                  <p className={`font-medium ${getConfidenceColor(prediction.confidence)}`}>
                    {prediction.confidence}%
                  </p>
                  <p className="text-gray-400 text-sm">Confidence</p>
                </div>
              </div>
              <div className="flex items-center space-x-6">
                <div className="flex items-center space-x-2">
                  <CloudRain className="w-4 h-4 text-blue-400" />
                  <span className="text-gray-300 text-sm">{prediction.weather}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4 text-purple-400" />
                  <span className="text-gray-300 text-sm">{prediction.events} events</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Prediction Factors */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Prediction Factors</h3>
          <div className="space-y-4">
            {factors.map((factor, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-gray-300 text-sm">{factor.name}</span>
                  <span className="text-white font-medium">{factor.impact}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div 
                    className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${factor.impact}%` }}
                  ></div>
                </div>
                <div className="flex items-center space-x-1">
                  <TrendingUp className={`w-3 h-3 ${
                    factor.trend === 'increasing' ? 'text-green-400' : 
                    factor.trend === 'decreasing' ? 'text-red-400' : 
                    'text-gray-400'
                  }`} />
                  <span className="text-xs text-gray-400 capitalize">{factor.trend}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Model Performance</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Accuracy</span>
              <span className="text-green-400 font-bold">92.4%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Precision</span>
              <span className="text-blue-400 font-bold">89.7%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Recall</span>
              <span className="text-purple-400 font-bold">91.2%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-300">F1 Score</span>
              <span className="text-amber-400 font-bold">90.4%</span>
            </div>
            <div className="mt-4 p-3 bg-gray-700 rounded-lg">
              <p className="text-sm text-gray-300">
                Model trained on 2.4M data points with continuous learning enabled.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Predictions;