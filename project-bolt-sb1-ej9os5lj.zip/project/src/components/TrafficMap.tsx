import React from 'react';
import { MapPin, Navigation, AlertTriangle, Clock } from 'lucide-react';

const TrafficMap: React.FC = () => {
  const trafficPoints = [
    { id: 1, name: 'Downtown Intersection', lat: 40.7128, lng: -74.0060, status: 'heavy', volume: 1250 },
    { id: 2, name: 'Highway 95 North', lat: 40.7589, lng: -73.9851, status: 'moderate', volume: 850 },
    { id: 3, name: 'Bridge Avenue', lat: 40.7505, lng: -73.9934, status: 'light', volume: 320 },
    { id: 4, name: 'Airport Access Road', lat: 40.6892, lng: -74.1745, status: 'heavy', volume: 1680 },
    { id: 5, name: 'Suburban Route 1', lat: 40.7831, lng: -73.9712, status: 'moderate', volume: 590 }
  ];

  const incidents = [
    { id: 1, type: 'accident', location: 'I-95 Mile 23', severity: 'high', eta: '45 min' },
    { id: 2, type: 'construction', location: 'Route 1 & Main St', severity: 'medium', eta: '2 hours' },
    { id: 3, type: 'weather', location: 'Highway 87', severity: 'low', eta: '30 min' }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'heavy':
        return 'bg-red-500';
      case 'moderate':
        return 'bg-yellow-500';
      case 'light':
        return 'bg-green-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'text-red-400';
      case 'medium':
        return 'text-yellow-400';
      case 'low':
        return 'text-green-400';
      default:
        return 'text-gray-400';
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Real-Time Traffic Map</h2>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <span className="text-sm text-gray-400">Heavy Traffic</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
            <span className="text-sm text-gray-400">Moderate Traffic</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="text-sm text-gray-400">Light Traffic</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Map Area */}
        <div className="lg:col-span-2 bg-gray-800 border border-gray-700 rounded-xl p-6">
          <div className="relative h-96 bg-gray-900 rounded-lg overflow-hidden">
            {/* Simulated Map Background */}
            <div className="absolute inset-0 bg-gradient-to-br from-gray-800 to-gray-900">
              <div className="absolute inset-0 opacity-20">
                <div className="w-full h-full bg-[radial-gradient(circle_at_50%_50%,rgba(59,130,246,0.3),transparent_70%)]"></div>
              </div>
            </div>
            
            {/* Traffic Points */}
            {trafficPoints.map((point, index) => (
              <div
                key={point.id}
                className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer group"
                style={{
                  left: `${20 + (index * 15)}%`,
                  top: `${30 + (index * 10)}%`
                }}
              >
                <div className={`w-4 h-4 rounded-full ${getStatusColor(point.status)} animate-pulse`}></div>
                <div className="absolute left-1/2 top-full mt-2 transform -translate-x-1/2 bg-gray-700 rounded-lg p-2 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                  <p className="text-white text-xs font-medium">{point.name}</p>
                  <p className="text-gray-300 text-xs">Volume: {point.volume}</p>
                  <p className="text-gray-300 text-xs">Status: {point.status}</p>
                </div>
              </div>
            ))}
            
            {/* Route Lines */}
            <svg className="absolute inset-0 w-full h-full">
              <path
                d="M 50 50 Q 150 100 300 150"
                stroke="rgba(59, 130, 246, 0.5)"
                strokeWidth="3"
                fill="none"
                strokeDasharray="5,5"
              />
              <path
                d="M 100 200 Q 200 150 350 180"
                stroke="rgba(16, 185, 129, 0.5)"
                strokeWidth="3"
                fill="none"
                strokeDasharray="5,5"
              />
            </svg>
          </div>
        </div>

        {/* Traffic Data Panel */}
        <div className="space-y-4">
          <div className="bg-gray-800 border border-gray-700 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-white mb-3">Traffic Points</h3>
            <div className="space-y-3">
              {trafficPoints.map((point) => (
                <div key={point.id} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <MapPin className="w-4 h-4 text-blue-400" />
                    <div>
                      <p className="text-white text-sm font-medium">{point.name}</p>
                      <p className="text-gray-400 text-xs">{point.volume} vehicles/hour</p>
                    </div>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${getStatusColor(point.status)}`}></div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gray-800 border border-gray-700 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-white mb-3">Active Incidents</h3>
            <div className="space-y-3">
              {incidents.map((incident) => (
                <div key={incident.id} className="p-3 bg-gray-700 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <AlertTriangle className={`w-4 h-4 ${getSeverityColor(incident.severity)}`} />
                      <span className="text-white text-sm font-medium capitalize">{incident.type}</span>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded ${
                      incident.severity === 'high' ? 'bg-red-900 text-red-200' :
                      incident.severity === 'medium' ? 'bg-yellow-900 text-yellow-200' :
                      'bg-green-900 text-green-200'
                    }`}>
                      {incident.severity}
                    </span>
                  </div>
                  <p className="text-gray-300 text-sm">{incident.location}</p>
                  <div className="flex items-center space-x-1 mt-2">
                    <Clock className="w-3 h-3 text-gray-400" />
                    <span className="text-gray-400 text-xs">ETA: {incident.eta}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrafficMap;