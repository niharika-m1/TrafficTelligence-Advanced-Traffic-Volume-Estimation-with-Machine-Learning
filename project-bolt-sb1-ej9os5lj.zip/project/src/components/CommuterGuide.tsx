import React, { useState } from 'react';
import { 
  Navigation, 
  Clock, 
  MapPin, 
  Route, 
  AlertTriangle, 
  Star,
  Car,
  Bus,
  Bike,
  Timer
} from 'lucide-react';

const CommuterGuide: React.FC = () => {
  const [origin, setOrigin] = useState('Downtown Office');
  const [destination, setDestination] = useState('Tech Hub');
  const [travelMode, setTravelMode] = useState('car');

  const routes = [
    {
      id: 1,
      name: 'Fastest Route',
      distance: '12.4 miles',
      duration: '28 min',
      traffic: 'moderate',
      savings: '5 min faster',
      path: 'I-95 N → Route 1 → Tech Hub Dr',
      incidents: 0
    },
    {
      id: 2,
      name: 'Scenic Route',
      distance: '14.2 miles',
      duration: '35 min',
      traffic: 'light',
      savings: '10 min in rush hour',
      path: 'Harbor Rd → Park Ave → Tech Hub Dr',
      incidents: 0
    },
    {
      id: 3,
      name: 'Highway Route',
      distance: '11.8 miles',
      duration: '42 min',
      traffic: 'heavy',
      savings: 'Avoid - 15 min delay',
      path: 'I-95 N → I-495 E → Tech Hub Dr',
      incidents: 2
    }
  ];

  const optimalTimes = [
    { time: '7:00 AM', duration: 22, traffic: 'light', savings: 'Best time' },
    { time: '8:00 AM', duration: 35, traffic: 'heavy', savings: '+13 min' },
    { time: '9:00 AM', duration: 28, traffic: 'moderate', savings: '+6 min' },
    { time: '10:00 AM', duration: 25, traffic: 'light', savings: '+3 min' },
    { time: '5:00 PM', duration: 45, traffic: 'heavy', savings: '+23 min' },
    { time: '6:00 PM', duration: 38, traffic: 'moderate', savings: '+16 min' },
    { time: '7:00 PM', duration: 30, traffic: 'light', savings: '+8 min' }
  ];

  const alternativeTransport = [
    {
      mode: 'bus',
      icon: Bus,
      duration: '45 min',
      cost: '$3.50',
      emissions: '80% less CO2',
      schedule: 'Every 15 min'
    },
    {
      mode: 'bike',
      icon: Bike,
      duration: '55 min',
      cost: 'Free',
      emissions: 'Zero emissions',
      schedule: 'Anytime'
    },
    {
      mode: 'car-pool',
      icon: Car,
      duration: '30 min',
      cost: '$2.50',
      emissions: '50% less CO2',
      schedule: 'Flexible'
    }
  ];

  const getTrafficColor = (traffic: string) => {
    switch (traffic) {
      case 'light':
        return 'text-green-400';
      case 'moderate':
        return 'text-yellow-400';
      case 'heavy':
        return 'text-red-400';
      default:
        return 'text-gray-400';
    }
  };

  const getTrafficBg = (traffic: string) => {
    switch (traffic) {
      case 'light':
        return 'bg-green-900';
      case 'moderate':
        return 'bg-yellow-900';
      case 'heavy':
        return 'bg-red-900';
      default:
        return 'bg-gray-900';
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Commuter Guidance</h2>
        <div className="flex items-center space-x-2 text-sm text-gray-400">
          <Navigation className="w-4 h-4" />
          <span>Real-time Navigation</span>
        </div>
      </div>

      {/* Trip Planner */}
      <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Trip Planner</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">From</label>
            <select 
              value={origin}
              onChange={(e) => setOrigin(e.target.value)}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white"
            >
              <option value="Downtown Office">Downtown Office</option>
              <option value="Residential Area">Residential Area</option>
              <option value="Shopping Mall">Shopping Mall</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">To</label>
            <select 
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white"
            >
              <option value="Tech Hub">Tech Hub</option>
              <option value="Airport">Airport</option>
              <option value="University">University</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Mode</label>
            <select 
              value={travelMode}
              onChange={(e) => setTravelMode(e.target.value)}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white"
            >
              <option value="car">Car</option>
              <option value="transit">Public Transit</option>
              <option value="bike">Bike</option>
              <option value="walk">Walk</option>
            </select>
          </div>
        </div>
      </div>

      {/* Route Options */}
      <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Route Options</h3>
        <div className="space-y-4">
          {routes.map((route) => (
            <div key={route.id} className="p-4 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors cursor-pointer">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-3">
                  <Route className="w-5 h-5 text-blue-400" />
                  <div>
                    <h4 className="text-white font-medium">{route.name}</h4>
                    <p className="text-gray-400 text-sm">{route.path}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {route.incidents > 0 && (
                    <AlertTriangle className="w-4 h-4 text-red-400" />
                  )}
                  <span className={`px-2 py-1 text-xs rounded-full ${getTrafficBg(route.traffic)} ${getTrafficColor(route.traffic)}`}>
                    {route.traffic}
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-gray-400">Distance</span>
                  <p className="text-white">{route.distance}</p>
                </div>
                <div>
                  <span className="text-gray-400">Duration</span>
                  <p className="text-white">{route.duration}</p>
                </div>
                <div>
                  <span className="text-gray-400">Savings</span>
                  <p className={route.savings.includes('faster') ? 'text-green-400' : 'text-red-400'}>
                    {route.savings}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Optimal Times */}
      <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Optimal Departure Times</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {optimalTimes.map((time, index) => (
            <div key={index} className="p-4 bg-gray-700 rounded-lg text-center">
              <div className="flex items-center justify-center space-x-2 mb-2">
                <Clock className="w-4 h-4 text-blue-400" />
                <span className="text-white font-medium">{time.time}</span>
              </div>
              <div className="space-y-1">
                <p className="text-2xl font-bold text-white">{time.duration} min</p>
                <p className={`text-sm ${getTrafficColor(time.traffic)}`}>{time.traffic} traffic</p>
                <p className={`text-xs ${time.savings === 'Best time' ? 'text-green-400' : 'text-red-400'}`}>
                  {time.savings}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Alternative Transport */}
      <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Alternative Transportation</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {alternativeTransport.map((transport, index) => {
            const Icon = transport.icon;
            return (
              <div key={index} className="p-4 bg-gray-700 rounded-lg">
                <div className="flex items-center space-x-3 mb-3">
                  <Icon className="w-6 h-6 text-blue-400" />
                  <h4 className="text-white font-medium capitalize">{transport.mode.replace('-', ' ')}</h4>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Duration</span>
                    <span className="text-white">{transport.duration}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Cost</span>
                    <span className="text-white">{transport.cost}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Environmental</span>
                    <span className="text-green-400">{transport.emissions}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Schedule</span>
                    <span className="text-white">{transport.schedule}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default CommuterGuide;