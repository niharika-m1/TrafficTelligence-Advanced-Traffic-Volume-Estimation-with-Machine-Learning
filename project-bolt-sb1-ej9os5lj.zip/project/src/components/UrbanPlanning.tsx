import React, { useState } from 'react';
import { 
  Building2, 
  MapPin, 
  TrendingUp, 
  Calendar, 
  Users, 
  Car,
  Construction,
  TreePine,
  Zap
} from 'lucide-react';

const UrbanPlanning: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState('project-1');
  const [timeframe, setTimeframe] = useState('5-years');

  const projects = [
    {
      id: 'project-1',
      name: 'Downtown Revitalization',
      type: 'Mixed-Use Development',
      status: 'Planning',
      impact: 'high',
      timeline: '2024-2028',
      trafficIncrease: 35,
      cost: 45000000
    },
    {
      id: 'project-2',
      name: 'Tech Hub Expansion',
      type: 'Commercial Complex',
      status: 'In Progress',
      impact: 'medium',
      timeline: '2024-2026',
      trafficIncrease: 22,
      cost: 28000000
    },
    {
      id: 'project-3',
      name: 'Residential District',
      type: 'Housing Development',
      status: 'Approved',
      impact: 'low',
      timeline: '2025-2027',
      trafficIncrease: 15,
      cost: 18000000
    }
  ];

  const trafficGrowth = [
    { year: '2024', current: 45000, projected: 48000, withPlanning: 46000 },
    { year: '2025', current: 47000, projected: 52000, withPlanning: 49000 },
    { year: '2026', current: 49000, projected: 58000, withPlanning: 52000 },
    { year: '2027', current: 51000, projected: 65000, withPlanning: 55000 },
    { year: '2028', current: 53000, projected: 72000, withPlanning: 58000 }
  ];

  const recommendations = [
    {
      category: 'Infrastructure',
      items: [
        'Add 2 new traffic signals at high-impact intersections',
        'Implement dedicated bus lanes on main corridors',
        'Expand highway access ramps capacity by 40%'
      ]
    },
    {
      category: 'Public Transit',
      items: [
        'Extend light rail to new tech hub area',
        'Add 3 new bus routes with 15-minute frequency',
        'Create integrated mobility hubs'
      ]
    },
    {
      category: 'Alternative Transport',
      items: [
        'Install 50 new bike-sharing stations',
        'Build protected bike lanes network',
        'Implement congestion pricing in downtown core'
      ]
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Planning':
        return 'bg-blue-900 text-blue-200';
      case 'In Progress':
        return 'bg-yellow-900 text-yellow-200';
      case 'Approved':
        return 'bg-green-900 text-green-200';
      default:
        return 'bg-gray-900 text-gray-200';
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high':
        return 'text-red-400';
      case 'medium':
        return 'text-yellow-400';
      case 'low':
        return 'text-green-400';
      default:
        return 'text-gray-400';
    }
  };

  const selectedProjectData = projects.find(p => p.id === selectedProject);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Urban Development Planning</h2>
        <div className="flex items-center space-x-4">
          <select 
            value={timeframe}
            onChange={(e) => setTimeframe(e.target.value)}
            className="bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm"
          >
            <option value="1-year">1 Year</option>
            <option value="3-years">3 Years</option>
            <option value="5-years">5 Years</option>
            <option value="10-years">10 Years</option>
          </select>
        </div>
      </div>

      {/* Project Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 bg-gray-800 border border-gray-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Development Projects</h3>
          <div className="space-y-4">
            {projects.map((project) => (
              <div 
                key={project.id}
                className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  selectedProject === project.id 
                    ? 'border-blue-500 bg-blue-900/20' 
                    : 'border-gray-600 bg-gray-700 hover:border-gray-500'
                }`}
                onClick={() => setSelectedProject(project.id)}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <Building2 className="w-5 h-5 text-blue-400" />
                    <div>
                      <h4 className="text-white font-medium">{project.name}</h4>
                      <p className="text-gray-400 text-sm">{project.type}</p>
                    </div>
                  </div>
                  <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(project.status)}`}>
                    {project.status}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="text-gray-400">Timeline</span>
                    <p className="text-white">{project.timeline}</p>
                  </div>
                  <div>
                    <span className="text-gray-400">Traffic Impact</span>
                    <p className={`font-medium ${getImpactColor(project.impact)}`}>
                      +{project.trafficIncrease}%
                    </p>
                  </div>
                  <div>
                    <span className="text-gray-400">Investment</span>
                    <p className="text-white">${(project.cost / 1000000).toFixed(0)}M</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Project Details */}
        <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Project Details</h3>
          {selectedProjectData && (
            <div className="space-y-4">
              <div>
                <h4 className="text-white font-medium">{selectedProjectData.name}</h4>
                <p className="text-gray-400 text-sm">{selectedProjectData.type}</p>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Status</span>
                  <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(selectedProjectData.status)}`}>
                    {selectedProjectData.status}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Timeline</span>
                  <span className="text-white">{selectedProjectData.timeline}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Traffic Impact</span>
                  <span className={`font-medium ${getImpactColor(selectedProjectData.impact)}`}>
                    +{selectedProjectData.trafficIncrease}%
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Investment</span>
                  <span className="text-white">${(selectedProjectData.cost / 1000000).toFixed(0)}M</span>
                </div>
              </div>

              <div className="pt-4 border-t border-gray-700">
                <h5 className="text-white font-medium mb-2">Impact Analysis</h5>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center space-x-2">
                    <Car className="w-4 h-4 text-blue-400" />
                    <span className="text-gray-300">Daily vehicles: +{Math.round(selectedProjectData.trafficIncrease * 150)}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-green-400" />
                    <span className="text-gray-300">New residents: {Math.round(selectedProjectData.cost / 50000)}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Construction className="w-4 h-4 text-yellow-400" />
                    <span className="text-gray-300">Construction phase: 2 years</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Traffic Growth Projection */}
      <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Traffic Growth Projections</h3>
        <div className="h-64 flex items-end justify-between space-x-2">
          {trafficGrowth.map((data, index) => (
            <div key={index} className="flex-1 flex flex-col items-center">
              <div className="w-full space-y-1">
                <div className="w-full bg-gray-700 rounded-t relative" style={{ height: `${(data.current / 80000) * 200}px` }}>
                  <div className="absolute inset-0 bg-gradient-to-t from-blue-600 to-blue-400 rounded-t"></div>
                </div>
                <div className="w-full bg-gray-700 rounded-t relative" style={{ height: `${(data.projected / 80000) * 200}px` }}>
                  <div className="absolute inset-0 bg-gradient-to-t from-red-600 to-red-400 rounded-t opacity-60"></div>
                </div>
                <div className="w-full bg-gray-700 rounded-t relative" style={{ height: `${(data.withPlanning / 80000) * 200}px` }}>
                  <div className="absolute inset-0 bg-gradient-to-t from-green-600 to-green-400 rounded-t opacity-80"></div>
                </div>
              </div>
              <span className="text-xs text-gray-400 mt-2">{data.year}</span>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-center space-x-6 mt-4">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-blue-500 rounded"></div>
            <span className="text-sm text-gray-400">Current</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded"></div>
            <span className="text-sm text-gray-400">Projected (No Planning)</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded"></div>
            <span className="text-sm text-gray-400">With Smart Planning</span>
          </div>
        </div>
      </div>

      {/* Recommendations */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {recommendations.map((rec, index) => (
          <div key={index} className="bg-gray-800 border border-gray-700 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">{rec.category}</h3>
            <div className="space-y-3">
              {rec.items.map((item, itemIndex) => (
                <div key={itemIndex} className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                  <p className="text-gray-300 text-sm">{item}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default UrbanPlanning;