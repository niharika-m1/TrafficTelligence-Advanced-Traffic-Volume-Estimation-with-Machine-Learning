import React, { useState } from 'react';
import { Route, TrafficCone as Traffic, Timer, Settings, Play, Pause, RotateCcw, CheckCircle, AlertTriangle } from 'lucide-react';

const DynamicManagement: React.FC = () => {
  const [isAutomationEnabled, setIsAutomationEnabled] = useState(true);
  const [selectedIntersection, setSelectedIntersection] = useState('intersection-1');

  const intersections = [
    { 
      id: 'intersection-1', 
      name: 'Main St & 1st Ave', 
      status: 'optimal', 
      volume: 850, 
      greenTime: 45, 
      redTime: 30 
    },
    { 
      id: 'intersection-2', 
      name: 'Highway 95 & Route 1', 
      status: 'congested', 
      volume: 1240, 
      greenTime: 60, 
      redTime: 20 
    },
    { 
      id: 'intersection-3', 
      name: 'Park Ave & Central St', 
      status: 'optimal', 
      volume: 620, 
      greenTime: 35, 
      redTime: 40 
    },
    { 
      id: 'intersection-4', 
      name: 'Airport Rd & Terminal Dr', 
      status: 'heavy', 
      volume: 1680, 
      greenTime: 75, 
      redTime: 15 
    }
  ];

  const optimizations = [
    { 
      id: 1, 
      intersection: 'Highway 95 & Route 1', 
      action: 'Extend green time by 15 seconds', 
      impact: '+12% flow improvement', 
      status: 'active' 
    },
    { 
      id: 2, 
      intersection: 'Main St & 1st Ave', 
      action: 'Activate adaptive timing', 
      impact: '+8% flow improvement', 
      status: 'pending' 
    },
    { 
      id: 3, 
      intersection: 'Airport Rd & Terminal Dr', 
      action: 'Implement dynamic lane control', 
      impact: '+18% flow improvement', 
      status: 'active' 
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'optimal':
        return 'text-green-400';
      case 'congested':
        return 'text-yellow-400';
      case 'heavy':
        return 'text-red-400';
      default:
        return 'text-gray-400';
    }
  };

  const getStatusBg = (status: string) => {
    switch (status) {
      case 'optimal':
        return 'bg-green-900';
      case 'congested':
        return 'bg-yellow-900';
      case 'heavy':
        return 'bg-red-900';
      default:
        return 'bg-gray-900';
    }
  };

  const selectedIntersectionData = intersections.find(i => i.id === selectedIntersection);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Dynamic Traffic Management</h2>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-400">Automation</span>
            <button
              onClick={() => setIsAutomationEnabled(!isAutomationEnabled)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                isAutomationEnabled ? 'bg-blue-600' : 'bg-gray-600'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  isAutomationEnabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${isAutomationEnabled ? 'bg-green-400 animate-pulse' : 'bg-gray-400'}`}></div>
            <span className="text-sm text-gray-400">
              {isAutomationEnabled ? 'Auto Mode' : 'Manual Mode'}
            </span>
          </div>
        </div>
      </div>

      {/* Control Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-gray-800 border border-gray-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Traffic Signal Control</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {intersections.map((intersection) => (
              <div 
                key={intersection.id} 
                className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  selectedIntersection === intersection.id 
                    ? 'border-blue-500 bg-blue-900/20' 
                    : 'border-gray-600 bg-gray-700 hover:border-gray-500'
                }`}
                onClick={() => setSelectedIntersection(intersection.id)}
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-white font-medium">{intersection.name}</h4>
                  <span className={`px-2 py-1 text-xs rounded-full ${getStatusBg(intersection.status)} ${getStatusColor(intersection.status)}`}>
                    {intersection.status}
                  </span>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-300">Volume</span>
                    <span className="text-white">{intersection.volume} veh/hr</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-300">Green Time</span>
                    <span className="text-white">{intersection.greenTime}s</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-300">Red Time</span>
                    <span className="text-white">{intersection.redTime}s</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Intersection Details */}
        <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Intersection Details</h3>
          {selectedIntersectionData && (
            <div className="space-y-4">
              <div className="text-center">
                <h4 className="text-white font-medium">{selectedIntersectionData.name}</h4>
                <span className={`inline-block px-3 py-1 text-sm rounded-full mt-2 ${getStatusBg(selectedIntersectionData.status)} ${getStatusColor(selectedIntersectionData.status)}`}>
                  {selectedIntersectionData.status}
                </span>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Current Volume</span>
                  <span className="text-white font-medium">{selectedIntersectionData.volume} veh/hr</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Green Phase</span>
                  <span className="text-green-400 font-medium">{selectedIntersectionData.greenTime}s</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Red Phase</span>
                  <span className="text-red-400 font-medium">{selectedIntersectionData.redTime}s</span>
                </div>
              </div>

              <div className="space-y-2">
                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors flex items-center justify-center space-x-2">
                  <Settings className="w-4 h-4" />
                  <span>Optimize Timing</span>
                </button>
                <button className="w-full bg-gray-600 hover:bg-gray-700 text-white py-2 px-4 rounded-lg transition-colors flex items-center justify-center space-x-2">
                  <RotateCcw className="w-4 h-4" />
                  <span>Reset to Default</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Active Optimizations */}
      <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Active Optimizations</h3>
        <div className="space-y-3">
          {optimizations.map((optimization) => (
            <div key={optimization.id} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
              <div className="flex items-center space-x-3">
                {optimization.status === 'active' ? (
                  <CheckCircle className="w-5 h-5 text-green-400" />
                ) : (
                  <AlertTriangle className="w-5 h-5 text-yellow-400" />
                )}
                <div>
                  <h4 className="text-white font-medium">{optimization.intersection}</h4>
                  <p className="text-gray-300 text-sm">{optimization.action}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-green-400 font-medium">{optimization.impact}</p>
                <span className={`inline-block px-2 py-1 text-xs rounded-full ${
                  optimization.status === 'active' 
                    ? 'bg-green-900 text-green-200' 
                    : 'bg-yellow-900 text-yellow-200'
                }`}>
                  {optimization.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DynamicManagement;