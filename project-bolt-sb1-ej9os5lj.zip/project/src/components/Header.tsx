import React from 'react';
import { Activity, Menu, Bell, Settings, User } from 'lucide-react';

interface HeaderProps {
  onMenuToggle: () => void;
  isMenuOpen: boolean;
}

const Header: React.FC<HeaderProps> = ({ onMenuToggle, isMenuOpen }) => {
  return (
    <header className="bg-gray-900 border-b border-gray-800 px-4 py-3 flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <button
          onClick={onMenuToggle}
          className="p-2 rounded-lg hover:bg-gray-800 transition-colors"
        >
          <Menu className="w-5 h-5 text-gray-300" />
        </button>
        <div className="flex items-center space-x-2">
          <Activity className="w-8 h-8 text-blue-400" />
          <div>
            <h1 className="text-xl font-bold text-white">TrafficTelligence</h1>
            <p className="text-xs text-gray-400">Advanced Traffic Analytics</p>
          </div>
        </div>
      </div>
      
      <div className="flex items-center space-x-3">
        <button className="p-2 rounded-lg hover:bg-gray-800 transition-colors relative">
          <Bell className="w-5 h-5 text-gray-300" />
          <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
        </button>
        <button className="p-2 rounded-lg hover:bg-gray-800 transition-colors">
          <Settings className="w-5 h-5 text-gray-300" />
        </button>
        <button className="p-2 rounded-lg hover:bg-gray-800 transition-colors">
          <User className="w-5 h-5 text-gray-300" />
        </button>
      </div>
    </header>
  );
};

export default Header;