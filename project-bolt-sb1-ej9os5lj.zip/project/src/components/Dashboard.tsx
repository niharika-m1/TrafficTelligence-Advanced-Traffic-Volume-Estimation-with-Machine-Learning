import React from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  Clock, 
  MapPin,
  AlertTriangle,
  CheckCircle,
  XCircle
} from 'lucide-react';

const Dashboard: React.FC = () => {
  const stats = [
    {
      title: 'Current Traffic Volume',
      value: '12,847',
      change: '+2.3%',
      trend: 'up',
      icon: Activity,
      color: 'blue'
    },
    {
      title: 'Average Speed',
      value: '32.4 mph',
      change: '-1.2%',
      trend: 'down',
      icon: TrendingDown,
      color: 'red'
    },
    {
      title: 'Predicted Peak Time',
      value: '8:45 AM',
      change: '+15 min',
      trend: 'up',
      icon: Clock,
      color: 'amber'
    },
    {
      title: 'Active Incidents',
      value: '7',
      change: '-3',
      trend: 'down',
      icon: AlertTriangle,
      color: 'green'
    }
  ];

  const recentAlerts = [
    { id: 1, type: 'high', message: 'Heavy congestion on I-95 North', time: '2 min ago', status: 'active' },
    { id: 2, type: 'medium', message: 'Minor accident on Route 1', time: '15 min ago', status: 'resolved' },
    { id: 3, type: 'low', message: 'Road construction scheduled', time: '1 hour ago', status: 'pending' },
    { id: 4, type: 'high', message: 'Weather alert: Heavy rain expected', time: '2 hours ago', status: 'active' }
  ];

  const trafficData = [
    { time: '6:00', volume: 2500, prediction: 2800 },
    { time: '7:00', volume: 4200, prediction: 4500 },
    { time: '8:00', volume: 8500, prediction: 8200 },
    { time: '9:00', volume: 12000, prediction: 12500 },
    { time: '10:00', volume: 9800, prediction: 10200 },
    { time: '11:00', volume: 7600, prediction: 7800 },
    { time: '12:00', volume: 11200, prediction: 11800 }
  ];

  const getStatColor = (color: string) => {
    const colors = {
      blue: 'bg-blue-500',
      red: 'bg-red-500',
      amber: 'bg-amber-500',
      green: 'bg-green-500'
    };
    return colors[color as keyof typeof colors] || 'bg-gray-500';
  };

  const getAlertIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <AlertTriangle className="w-4 h-4 text-red-400" />;
      case 'resolved':
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      default:
        return <XCircle className="w-4 h-4 text-gray-400" />;
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Traffic Intelligence Dashboard</h2>
        <div className="flex items-center space-x-2 text-sm text-gray-400">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span>Live Data</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-gray-800 border border-gray-700 rounded-xl p-6 hover:border-gray-600 transition-colors">
              <div className="flex items-center justify-between">
                <div className={`p-3 rounded-lg ${getStatColor(stat.color)}`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className={`flex items-center space-x-1 text-sm ${
                  stat.trend === 'up' ? 'text-green-400' : 'text-red-400'
                }`}>
                  {stat.trend === 'up' ? (
                    <TrendingUp className="w-4 h-4" />
                  ) : (
                    <TrendingDown className="w-4 h-4" />
                  )}
                  <span>{stat.change}</span>
                </div>
              </div>
              <div className="mt-4">
                <h3 className="text-2xl font-bold text-white">{stat.value}</h3>
                <p className="text-gray-400 text-sm">{stat.title}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Traffic Volume Chart */}
      <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Traffic Volume vs Predictions</h3>
        <div className="h-64 flex items-end justify-between space-x-2">
          {trafficData.map((data, index) => (
            <div key={index} className="flex-1 flex flex-col items-center">
              <div className="w-full flex flex-col items-center space-y-1">
                <div className="w-full bg-gray-700 rounded-t relative" style={{ height: `${(data.volume / 15000) * 200}px` }}>
                  <div className="absolute inset-0 bg-gradient-to-t from-blue-600 to-blue-400 rounded-t"></div>
                </div>
                <div className="w-full bg-gray-700 rounded-t relative" style={{ height: `${(data.prediction / 15000) * 200}px` }}>
                  <div className="absolute inset-0 bg-gradient-to-t from-green-600 to-green-400 rounded-t opacity-60"></div>
                </div>
              </div>
              <span className="text-xs text-gray-400 mt-2">{data.time}</span>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-center space-x-6 mt-4">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-blue-500 rounded"></div>
            <span className="text-sm text-gray-400">Actual Volume</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded"></div>
            <span className="text-sm text-gray-400">Predicted Volume</span>
          </div>
        </div>
      </div>

      {/* Recent Alerts */}
      <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Recent Alerts</h3>
        <div className="space-y-3">
          {recentAlerts.map((alert) => (
            <div key={alert.id} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
              <div className="flex items-center space-x-3">
                {getAlertIcon(alert.status)}
                <div>
                  <p className="text-white text-sm">{alert.message}</p>
                  <p className="text-gray-400 text-xs">{alert.time}</p>
                </div>
              </div>
              <span className={`px-2 py-1 rounded-full text-xs ${
                alert.status === 'active' ? 'bg-red-900 text-red-200' :
                alert.status === 'resolved' ? 'bg-green-900 text-green-200' :
                'bg-gray-900 text-gray-200'
              }`}>
                {alert.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;