import React, { useState } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import TrafficMap from './components/TrafficMap';
import Predictions from './components/Predictions';
import DynamicManagement from './components/DynamicManagement';
import UrbanPlanning from './components/UrbanPlanning';
import CommuterGuide from './components/CommuterGuide';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');

  const handleMenuToggle = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'traffic-map':
        return <TrafficMap />;
      case 'predictions':
        return <Predictions />;
      case 'dynamic-mgmt':
        return <DynamicManagement />;
      case 'urban-planning':
        return <UrbanPlanning />;
      case 'commuter-guide':
        return <CommuterGuide />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Header onMenuToggle={handleMenuToggle} isMenuOpen={isMenuOpen} />
      <div className="flex">
        <Sidebar 
          isOpen={isMenuOpen} 
          activeTab={activeTab} 
          onTabChange={setActiveTab} 
        />
        <main className="flex-1 overflow-x-hidden">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}

export default App;